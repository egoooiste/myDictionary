﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace MyDictionary
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

            this.button1.Enabled = false;          
        }

        public static string word { get; set; }
        public static string translate { get; set; }

        //Add new word to dictionary
        private void button1_Click(object sender, EventArgs e)
        {
            //it's this must be checked about language Enter
            bool flag_word = DictionaryWindow.CheckLanguage(textBox1.Text, DictionaryWindow.rus_alphabet);

            if (flag_word)
            {
                if (DictionaryWindow.ht_buf.ContainsKey(textBox1.Text))
                {
                    MessageBox.Show("This word exists in Dictionary");
                    textBox1.Text = textBox2.Text = "";
                    this.button1.Enabled = false;
                }
                else
                {
                    bool flag_translate = DictionaryWindow.CheckLanguage(textBox2.Text, DictionaryWindow.eng_alphabet);

                    if (flag_translate)
                    {
                        this.button1.Enabled = true;
                        word = textBox1.Text;
                        translate = textBox2.Text;

                        word.ToLower();

                        translate.ToLower();

                        this.Close();
                    }
                    else
                        MessageBox.Show("Enter only english symbols");
                }
            }
            else
                MessageBox.Show("Enter only russian symbols");            
        }

        //Canceled add new word to dictionary
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1 = textBox2 = null;
             
            this.Close();
        }       

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                this.button1.Enabled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                this.button1.Enabled = true;
            }
        }

    }
}
