﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Threading;

namespace MyDictionary
{
    public partial class Form1 : Form
    {    
        public Form1()
        {
            InitializeComponent();

            listView1.FullRowSelect = true;
        }        
        
        //Full path at files dictionary
        public static string[] dicFiles;

        //It is only names files
        public static string[] nameFiles;

        //Name file used programm at the moment
        public static string GetNameSTR { get; set; }
      
        //Path to Folder with Dictionary
        public static string path = Environment.CurrentDirectory + "\\docs\\";

        public string path_img = Environment.CurrentDirectory;

        private static int c = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            c++;

           this.listView1.Items.Clear();

           ListViewMain(ref dicFiles, ref nameFiles);  

            if(c > 1)
               this.listView1.FocusedItem.Focused = false;
        }
        
        //Method update listView, dicFiles, nameFiles
        public void ListViewMain(ref string[] dicFiles, ref string[] nameFiles)
        {
            dicFiles = Directory.GetFileSystemEntries(path);
            nameFiles = new string[dicFiles.Length];
            
            for (int i = 0; i < dicFiles.Length; i++)
            {
                 string[] str = dicFiles[i].Split('\\');

                nameFiles[i] = str[str.Length - 1];
            }
            
            for (int i = 0; i < dicFiles.Length; i++)
                listView1.Items.Add(nameFiles[i]);            
        }

        //Delete file dictionary
        private void button2_Click(object sender, EventArgs e)
        {
            //selected listView Item
            ListViewItem lvI = new ListViewItem();

            lvI = listView1.FocusedItem;

            if (lvI != null)
            {
                var result = MessageBox.Show("Do you indeed delete Dictionary?\n\n" + listView1.FocusedItem.Text, "Menu delete", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    DeleteDictionary();                   
                }
            }
            else
                MessageBox.Show("Select file on list");      
        }      

        //Delete Dictionary File - only for - button2_Click
        private void DeleteDictionary()
        {
            //selected listView Item
            ListViewItem lvI = new ListViewItem();

            lvI = listView1.FocusedItem;

            if (lvI != null)
            {
                for (int i = 0; i < dicFiles.Length; i++)
                    if (dicFiles[i].EndsWith(lvI.Text))
                    {
                        File.Delete(dicFiles[i]);
                        break;
                    }
                this.listView1.Items.Clear();
                ListViewMain(ref dicFiles, ref nameFiles);
            }
            else
                MessageBox.Show("Select file on list");      
        }

        //Open file Dictionary
        private void button3_Click(object sender, EventArgs e)
        {             
            //selected listView Item
            ListViewItem lvI = new ListViewItem();

            lvI = listView1.FocusedItem;

            if (lvI != null)
            {
                GetNameSTR = lvI.Text;

                DictionaryWindow DW = new DictionaryWindow();

                DW.Show();
            }
            else
                MessageBox.Show("Select file on list");               
        }               

        //Create New file Dictionary
        private void button1_Click(object sender, EventArgs e)
        {
            FormNewDic fnd = new FormNewDic();

            fnd.ShowDialog();
            
            //update listView1
            this.listView1.Items.Clear();
            ListViewMain(ref dicFiles, ref nameFiles);
        }

        //Close Form
        private void button4_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            this.listView1.Items.Clear();
            ListViewMain(ref dicFiles, ref nameFiles);
        }
    }    
}
