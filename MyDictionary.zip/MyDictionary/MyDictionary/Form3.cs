﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace MyDictionary
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

            my = DictionaryWindow.ht_buf.Keys;
            my2 = DictionaryWindow.ht_buf.Values;
            arr_key = new ArrayList(my);
            arr_value = new ArrayList(my2);
            arr_int = new ArrayList();
            tmp_str = null;
            i = 0;
            mistake = 0;
            tmp = 0;
        }

        Random rnd = new Random();

        static  ICollection my;

        static ICollection my2;

        static ArrayList arr_key;

        static ArrayList arr_value;

        static ArrayList arr_int;

        String[] str;

        int tmp;

        string tmp_str;

        static int i = 0;

        static int mistake = 0;

        private void Form3_Load(object sender, EventArgs e)
        {
            if(DictionaryWindow.B1 || DictionaryWindow.B3)
                TrainRusEng(arr_key, arr_value);
            if (DictionaryWindow.B2 || DictionaryWindow.B4)
                TrainRusEng(arr_value, arr_key);
        }

        //Add and sort words for multi chose
        public string [] SortValues(string s, ArrayList ar)
        {
            String[] str = new string[6];

            str[0] = s;

            ArrayList mass_int = new ArrayList();

            //Add Random words to str
            for (int i = 1; i < str.Length; i++)
            {
                if (str.Length > ar.Count && i >= ar.Count)
                    str[i] = "";
                else
                {
                    int x = rnd.Next(0, ar.Count);

                    if (mass_int.Contains(x))
                    {
                        i--;
                        continue;
                    }

                    str[i] = ar[x].ToString();

                    if (str[i] == s)
                    {
                        i--;
                        continue;
                    }

                    mass_int.Add(x);
                }
            }
            
            mass_int.Clear();

            string tmp ;

            //Sort array str - Random
            for (int i = 0; i < str.Length; i++)
            {
                int x = rnd.Next(0, str.Length - 1);

                if (mass_int.Contains(x))
                {
                    i--;
                continue;
                }

                tmp = str[0];
                str[0] = str[x];
                str[x] = tmp;
            }
            return str;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == tmp_str)
                Form3_Load(sender, e);
            else
                mistake++;

            Info();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == tmp_str)
                Form3_Load(sender, e);
            else
                mistake++;

            Info();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text == tmp_str)
                Form3_Load(sender, e);
            else
                mistake++;

            Info();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == tmp_str)
                Form3_Load(sender, e);
            else
                mistake++;

            Info();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text == tmp_str)
                Form3_Load(sender, e);
            else
                mistake++;

            Info();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (button6.Text == tmp_str)
                Form3_Load(sender, e);
            else
                mistake++;

            Info();
        }

        private void TrainRusEng(ArrayList a_key, ArrayList a_value)
        {
            if (i == DictionaryWindow.ht_buf.Keys.Count && DictionaryWindow.ht_buf.Keys.Count != 0)
            {
                MessageBox.Show("Test finish\n\nMistakes: " + mistake + "\n\nFrom: " + i + " words");

                mistake = 0;
                i = 0;
                tmp = 0;
                tmp_str = "";
                arr_int.Clear();

                this.Close();
            }
            else
            {               

                while (i++ < a_key.Count)
                {
                    //Get recognaze word with translate
                    tmp = rnd.Next(0, a_key.Count);

                    if (arr_int.Contains(tmp))
                    {
                        i--;
                        continue;
                    }

                    arr_int.Add(tmp);
                    break;
                }
                Info();                

                //word
                label1.Text = a_key[tmp].ToString();

                //translate
                tmp_str = a_value[tmp].ToString();

                str = SortValues(tmp_str, a_value);

                button1.Text = str[0];

                button2.Text = str[1];

                button3.Text = str[2];

                button4.Text = str[3];

                button5.Text = str[4];

                button6.Text = str[5];
            }
        }

        //Close test
        private void button7_Click(object sender, EventArgs e)
        {
                this.Close();  
        }

        private void Info()
        {
            this.Text = "  words: " + DictionaryWindow.ht_buf.Keys.Count + "  from: " + (i) + "   mistakes: " + mistake;
        }

    }
}
