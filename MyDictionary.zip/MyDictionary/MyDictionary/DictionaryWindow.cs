﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Threading;

namespace MyDictionary
{
    public partial class DictionaryWindow : Form
    {
        public DictionaryWindow()
        {
            InitializeComponent();

            this.radioButton1.Select();

            B1 = this.radioButton1.Checked;            
        }       
        
        private Hashtable ht = new Hashtable();

        public static Hashtable ht_buf = new Hashtable();
        
        private void DictionaryWindow_Load(object sender, EventArgs e)
        {
            try
                {
                     //Clear Data sourses
                    ht.Clear();
                    ht_buf.Clear();
                    listBox1.Items.Clear();
                    textBox1.Clear();
                    listBox1.SelectedItems.Clear();
                    flag_del = null;
                    
                    if (th != null)
                        th.Abort();                    

                    string[] current_name = Form1.GetNameSTR.Split('.');

                    if (current_name[1] == "txt")
                    {
                        //Opening Text Format - Dictionary  file for read
                        using (StreamReader sr = new StreamReader(Form1.path + Form1.GetNameSTR, Encoding.Default))
                        {
                            HashTableUpdate(ht, sr);

                            ListBoxUpdate(ref ht);

                            sr.Close();
                        }

                        this.Text = "Dictionary: " + Form1.GetNameSTR + " |  words: " + ht.Count;
                    }
                    else
                    {
                        MessageBox.Show("Uknow Format File\n\nTry only ( *.txt ) file", "Warning!!!", MessageBoxButtons.OK);
                        this.Close();
                    }       
               }
             catch (Exception)
                {
                   MessageBox.Show("Uknow format file");
                   this.Close();
                }
         }

        //Method parse string and add to HashTable
        private void HashTableUpdate(Hashtable ht, StreamReader sr)
        {
            string str;

            int count = 0;

            while ((str = sr.ReadLine()) != null)
            {
                if (str == "")
                {
                    count++;

                    if (count > 10)
                        break;

                    continue;
                }

                    str = str.ToLower();

                    string[] tmp;

                    tmp = ParseIncomeStr(ref str);

                    if (ht.Count != 0)
                    {
                        if (ht.ContainsKey(tmp[0]))
                        {
                            MessageBox.Show("Key's word  \"" + tmp[0] + "-" + tmp[1] + "\"  are exist \n\ninfo: you must change this word in your dictionary!!!");
                            continue;
                        }
                    }

                    ht.Add(tmp[0], tmp[1]);
                    ht_buf.Add(tmp[0], tmp[1]);

                    count = 0;
            }
        }
                
        private void ListBoxUpdate(ref Hashtable ht)
        {
            ICollection mKey = ht.Keys;

            foreach (string s in mKey)
                listBox1.Items.Add(s + " - " + ht[s]);
        }

        private void ListBoxUpdate2(ref Hashtable ht)
        {
            ICollection mKey = ht.Keys;

            foreach (string s in mKey)
                listBox1.Items.Add(ht[s] + " - " + s );
        }

        private void ListBoxUpdateRus(ref Hashtable ht)
        {
            ICollection mKey = ht.Keys;

            foreach (string s in mKey)
                listBox1.Items.Add(s);
        }

        private void ListBoxUpdateEng(ref Hashtable ht)
        {
            ICollection mKey = ht.Keys;

            foreach (string s in mKey)
                listBox1.Items.Add(ht[s]);
        }        

        // Add new word with translate to dictionary
        private void button4_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();

            f2.ShowDialog();

            if ((Form2.word != "" && Form2.translate != "")&&(Form2.word != null && Form2.translate != null))
            {
                ht_buf.Add(Form2.word, Form2.translate);

                listBox1.Items.Clear();

                GeneralUpdateRadiobuttons();

                Form2.word = "";
                Form2.translate = "";
            }

            listBox1.SelectedItems.Clear();
        }

        private void GeneralUpdateRadiobuttons()
        {
            if (radioButton1.Checked)
                ListBoxUpdate(ref ht_buf);

            if (radioButton2.Checked)
                ListBoxUpdateEng(ref ht_buf);

            if (radioButton3.Checked)
                ListBoxUpdateRus(ref ht_buf);

            if (radioButton4.Checked)
                ListBoxUpdate2(ref ht_buf);
        }

        //It's listBox1.SelectedItem
        private object flag_del;

        //Delete from listBox1 and Dictionary - selected word with translate
        private void button5_Click(object sender, EventArgs e)
        {   
            flag_del = listBox1.SelectedItem;

            string str = null;

            ArrayList arr = new ArrayList();

            if (flag_del == null)
                MessageBox.Show("Don't selected word");
            else
            {
                str = flag_del.ToString();

                if (radioButton2.Checked || radioButton4.Checked)
                {                 
                    if (radioButton4.Checked)
                    {
                        String[] tmp;

                        tmp = str.Split('-');

                        foreach (string s in tmp)
                            if (CheckLanguage(s, rus_alphabet))
                                str = s;

                        str = PhraseAlgorithm(str, arr);
                    }
                    if (radioButton2.Checked)
                    {
                        str = PhraseAlgorithm(str, arr);

                        String[] arr_keys = new string[ht_buf.Count];
                        String[] arr_values = new string[ht_buf.Count];

                        ht_buf.Keys.CopyTo(arr_keys, 0);
                        ht_buf.Values.CopyTo(arr_values, 0);

                        for (int i = 0; i < arr_values.Length; i++)
                            if(arr_values[i] == str)
                            {
                                str = arr_keys[i];
                                    break;
                            }
                    }
                }

                if (radioButton1.Checked || radioButton3.Checked)
                {
                    if (radioButton1.Checked)
                    {
                        String[] tmp;

                        tmp = str.Split('-');

                        foreach (string s in tmp)
                            if (CheckLanguage(s, rus_alphabet))
                                str = s;

                        str = PhraseAlgorithm(str, arr);
                    }

                    if (radioButton3.Checked)
                    {
                        str = PhraseAlgorithm(str, arr);
                    }
                }
                    //It's delete item
                    ht_buf.Remove(str);

                    listBox1.Items.Clear();

                    GeneralUpdateRadiobuttons();

                    listBox1.SelectedItems.Clear();             
            }
        }

        //Method Parse string for unresolved symbols apart ('-','_',' ')
        public static string SpaceDel(ref string str)
        {
            char[] ch;

            ch = str.ToCharArray(0, str.Length);

            ArrayList arr = new ArrayList();

            str = "";

            for (int i = 0; i < ch.Length; i++)
            {
                if (ch[i] == '=' || ch[i] == '.' || ch[i] == ',' || ch[i] == '\\' || ch[i] == ';' || ch[i] == ':' || ch[i] == '\'' || ch[i] == '\"' || ch[i] == '|' || ch[i] == '/' || ch[i] == '<' || ch[i] == '>' || ch[i] == '?' || ch[i] == '!' || ch[i] == '@' || ch[i] == '$' || ch[i] == '%' || ch[i] == '*' || ch[i] == '(' || ch[i] == ')' || ch[i] == '{' || ch[i] == '}' || ch[i] == '[' || ch[i] == ']' || ch[i] == '+' || ch[i] == '`' || ch[i] == '~' || ch[i] == '#' || ch[i] == '^')
                      continue;
               
                str += ch[i];
            }
            return str;
        }

        public static string SpaceDelAfter(ref string str)
        {
            char[] ch;

            ch = str.ToCharArray(0, str.Length);

            str = "";

            int count = 0;

            for (int i = ch.Length - 1; i >= 0; i--)
                if (ch[i] == ' ')
                    count++;
                else
                    break;
                          
            for(int j = 0; j < ch.Length - count; j++)
                str += ch[j];

            return str;
        }

        //Method Parse string for unresolved symbols FOR phrase
        private string PhraseAlgorithm(string str, ArrayList arr)
        {
            char[] ch;

            ch = str.ToCharArray(0, str.Length);

            str = "";

            int count = 0;

            for (int i = 0; i < ch.Length; i++)
            {
                if (ch[i] == '-' || ch[i] == ' ' || ch[i] == '=' || ch[i] == '_' || ch[i] == '.' || ch[i] == ',' || ch[i] == '\\' || ch[i] == ';' || ch[i] == ':' || ch[i] == '\'' || ch[i] == '\"' || ch[i] == '|' || ch[i] == '/' || ch[i] == '<' || ch[i] == '>' || ch[i] == '?' || ch[i] == '!' || ch[i] == '@' || ch[i] == '$' || ch[i] == '%' || ch[i] == '*' || ch[i] == '(' || ch[i] == ')' || ch[i] == '{' || ch[i] == '}' || ch[i] == '[' || ch[i] == ']' || ch[i] == '+' || ch[i] == '`' || ch[i] == '~' || ch[i] == '#' || ch[i] == '^' || ch[i] == '&' || ch[i] == '0' || ch[i] == '1' || ch[i] == '2' || ch[i] == '3' || ch[i] == '4' || ch[i] == '5' || ch[i] == '6' || ch[i] == '7' || ch[i] == '8' || ch[i] == '9')
                {
                    if (str.Length != 0)
                    {
                        if (ch[i] == ',' || ch[i] == ' ')
                        {                            
                            if (ch[i] == ',')
                            {
                                str += ch[i];
                                count = 0;
                            }
                            
                            if (ch[i] == ' ')
                            {
                                count++;

                                if(count > 1)
                                    continue;

                                str += ch[i];
                                
                                continue;
                            }
                        }

                        arr.Add(str);
                        str = "";
                    }
                    continue;
                }
                str += ch[i];
                count = 0;
            }

            if (str.Length != 0)
            {
                arr.Add(str);
                str = "";
            }

            foreach (string s in arr)
                str += s + " ";

            str = str.Substring(0, str.Length - 1);

            return str;
        }

        //Parse income string - return array[] to word and translate
         public string[] ParseIncomeStr(ref string str)
        {    
            ArrayList arr = new ArrayList();

            PhraseAlgorithm(str, arr);

            String[] tmp = new string[2];

            for (int i = 0; i < arr.Count; i++)
            {
                if (CheckLanguage(arr[i].ToString(), rus_alphabet))
                {
                    tmp[0] += arr[i].ToString() + " ";

                    continue;
                }
                if (CheckLanguage(arr[i].ToString(), eng_alphabet))
                {
                    tmp[1] += arr[i].ToString() + " ";

                    continue;
                }
            }

            tmp[0] = SpaceDelAfter(ref tmp[0]);
            tmp[1] = SpaceDelAfter(ref tmp[1]);

            return tmp;
        }

        //Save Dictionary to File dictionary
        private void button2_Click(object sender, EventArgs e)
        {
            ICollection ht1 = ht.Keys;
            
            bool flag = false;

            //Comparer ht and ht_buf dictionary on changing
            if (ht.Count == ht_buf.Count)
            {
                foreach (string s in ht1)
                    if (ht[s] != ht_buf[s])
                    {
                        flag = true;
                        break;
                    }
            }
            else
                flag = true;

                if (flag)
                {
                    var result = MessageBox.Show("Do you want to rewriting file dictionary?\n\n" + Form1.GetNameSTR, "Save menu", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {                        
                        SaveDictionaryToFile();
                    }
                    else
                    {
                        var res = MessageBox.Show("Do you want to create new file dictionary?\n\n", "Save menu", MessageBoxButtons.YesNo);

                        if (res == DialogResult.Yes)
                        {
                            FormNewDic fnd = new FormNewDic();

                            fnd.ShowDialog();
                            
                            SaveDictionaryToFile();
                        }
                    }
                }                
        }

        //Method Save Dictionary to Text or Binary file Format
        private void SaveDictionaryToFile()
        {
            try
            {
                string[] current_name = Form1.GetNameSTR.Split('.');

                if (current_name[1] == "txt")
                {
                    //Write file to Text Format view
                    using (StreamWriter sw = new StreamWriter(Form1.path + Form1.GetNameSTR, false, Encoding.UTF8))
                    {
                        String[] arr_keys = new string[ht_buf.Count];
                        String[] arr_values = new string[ht_buf.Count];

                        ht_buf.Keys.CopyTo(arr_keys, 0);
                        ht_buf.Values.CopyTo(arr_values, 0);

                        for (int i = 0; i < ht_buf.Count; i++)
                            sw.WriteLine(arr_keys[i] + "-" + arr_values[i]);

                        sw.Close();
                    }
                }               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static bool B1 { get; set; }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            RadiobuttonOption();
            ListBoxUpdate(ref ht_buf);
            B1 = this.radioButton1.Checked;   
        }

        public static bool B4 { get; set; }
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            RadiobuttonOption();
            ListBoxUpdate2(ref ht_buf);
            B4 = this.radioButton4.Checked;            
        }

        public static bool B2 { get; set; }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            RadiobuttonOption();
            ListBoxUpdateEng(ref ht_buf);
            B2 = this.radioButton2.Checked;            
        }

        public static bool B3 { get; set; }
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            RadiobuttonOption();
            ListBoxUpdateRus(ref ht_buf);
            B3 = this.radioButton3.Checked; 
        }

        //Clear and change listBox items
        private void RadiobuttonOption()
        {
            textBox1.Text = "";
            listBox1.SelectedItems.Clear();
            listBox1.Items.Clear();
            flag_del = listBox1.SelectedItem;
        }

        //listView Sort words to order alfabet
        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Clear();
            listBox1.Items.Clear();

            ICollection myDict = ht_buf.Keys;

            if (radioButton1.Checked || radioButton3.Checked)
            {            
                SortedDictionary<string, string> dict = new SortedDictionary<string, string>();

                foreach (string s in myDict)
                    dict.Add(s, ht_buf[s].ToString());

                //Show only russian and english words
                if (radioButton1.Checked)
                    foreach (var s in dict)
                        listBox1.Items.Add(s.Key + " - " + s.Value);

                //Show only russian words
                if (radioButton3.Checked)
                    foreach (var s in dict)
                        listBox1.Items.Add(s.Key);
            }
            if (radioButton2.Checked || radioButton4.Checked)
            {
                SortedDictionary<string, string> dict = new SortedDictionary<string, string>();

                foreach (string s in myDict)
                    dict.Add(ht_buf[s].ToString(), s);

                //Show only english and russian words
                if (radioButton4.Checked)
                    foreach (var s in dict)
                        listBox1.Items.Add(s.Key + " - " + s.Value);

                //Show only english words
                if (radioButton2.Checked)
                    foreach (var s in dict)
                        listBox1.Items.Add(s.Key);
            }
        }  
        
        //Show in listBox words only start with textBox symbols
        private void SearchTextBoxWordKey(ref Hashtable ht_buf)
        {
            ICollection my = ht_buf.Keys;

            listBox1.Items.Clear();

            foreach (string s in my)
            {
                if (radioButton1.Checked)
                    if (s.StartsWith(textBox1.Text))
                        listBox1.Items.Add(s + " - " + ht_buf[s]);
                
                if (radioButton3.Checked)
                    if (s.StartsWith(textBox1.Text))
                        listBox1.Items.Add(s);
             }
        }

        //Show in listBox words only start with textBox symbols
        private void SearchTextBoxWordValue(ref Hashtable ht_buf)
        {
            ICollection my = ht_buf.Keys;

            listBox1.Items.Clear();

            foreach (string s in my)
            {
                if (radioButton4.Checked)
                    if (ht_buf[s].ToString().StartsWith(textBox1.Text))
                        listBox1.Items.Add(ht_buf[s] + " - " + s);

                if (radioButton2.Checked)
                    if (ht_buf[s].ToString().StartsWith(textBox1.Text))
                        listBox1.Items.Add(ht_buf[s]);
            }
        }

        Thread th;
        
       //Enter symbol or symbols and Show words start with this symbols
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {            
            if (th != null)
                th.Abort();            

            if (radioButton1.Checked)
            {        
                th = new Thread(TextBoxKeyPressRusEng);
                th.IsBackground = true;
                th.Start();                
            }

            if (radioButton4.Checked)
            {
                th = new Thread(TextBoxKeyPressEngRus);
                th.IsBackground = true;
                th.Start();
            }
            if (radioButton2.Checked)
            {
                th = new Thread(TextBoxKeyPressEng);
                th.IsBackground = true;
                th.Start();
            }

            if (radioButton3.Checked)
            {
                th = new Thread(TextBoxKeyPressRus);
                th.IsBackground = true;
                th.Start();
            }
        }

        //Method for open new Thread
        private void TextBoxKeyPressRusEng()
        {
            if (ht_buf.Count == 0)
                MessageBox.Show("Add words");
            else
                if (textBox1.TextLength > 20 || textBox1.TextLength < 0)
                    MessageBox.Show("It's the longest word");
                else
                    if (textBox1.Text.Length == 0)
                    {
                        listBox1.Items.Clear();
                        ListBoxUpdate(ref ht_buf);
                    }
                    else
                      SearchTextBoxWordKey(ref ht_buf);
        }

        //Method for open new Thread
        private void TextBoxKeyPressEngRus()
        {
            if (ht_buf.Count == 0)
                MessageBox.Show("Add words");
            else
                if (textBox1.TextLength > 20 || textBox1.TextLength < 0)
                    MessageBox.Show("It's the longest word");
                else
                    if (textBox1.Text.Length == 0)
                    {
                        listBox1.Items.Clear();
                        ListBoxUpdate2(ref ht_buf);
                    }
                    else
                        SearchTextBoxWordValue(ref ht_buf);
        }        

        //Method for open new Thread
        private void TextBoxKeyPressRus()
        {
            if (ht_buf.Count == 0)
                MessageBox.Show("Add words");
            else
                if (textBox1.TextLength > 20 || textBox1.TextLength < 0)
                    MessageBox.Show("It's the longest word");
                else
                    if (textBox1.Text.Length == 0)
                    {
                        listBox1.Items.Clear();
                        ListBoxUpdateRus(ref ht_buf);
                    }
                    else
                        SearchTextBoxWordKey(ref ht_buf);
        }
        //Method for open new Thread
        private void TextBoxKeyPressEng()
        {
            if (ht_buf.Count == 0)
                MessageBox.Show("Add words");
            else
                if (textBox1.TextLength > 20 || textBox1.TextLength < 0)
                    MessageBox.Show("It's the longest word");
                else
                   if (textBox1.Text.Length == 0)
                    {
                        listBox1.Items.Clear();
                        ListBoxUpdateEng(ref ht_buf);
                    }
                    else
                        SearchTextBoxWordValue(ref ht_buf);
        }
       
        //Selected item - show translate word in toolTip
        private void listBox1_Click(object sender, EventArgs e)
        {
            ICollection my = ht_buf.Keys;

            if (radioButton2.Checked)
                foreach (string s in my)
                    if (listBox1.SelectedItem.ToString() == ht_buf[s].ToString())
                    {
                        toolTip1.Show("     " + s, listBox1);
                        break;
                    }

            if (radioButton3.Checked)
                foreach (string s in my)
                    if (listBox1.SelectedItem.ToString() == s)
                    {
                        toolTip1.Show("     " + ht_buf[s].ToString(), listBox1);
                        break;
                    }
        }                

        //Close form
        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Clear();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            bool flag_rus = CheckLanguage(textBox1.Text, rus_alphabet);
            bool flag_eng = CheckLanguage(textBox1.Text, eng_alphabet);
        }

        public static char[] rus_alphabet = { 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я' };

        public static char[] eng_alphabet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
        
        //Checker language correct
        public static bool CheckLanguage(string str, char[] alphabet)
        {
            bool flag = false;

            if (str.Length == 0)
                str = "";
            else
            {
                char[] ch = str.ToCharArray(0, str.Length);

                //Sort sybols ch[] for fasting cheak simila or no
                List<char> sort = new List<char>();

                sort.AddRange(ch);

                sort.Sort();

                int count = 0;

                if (!flag)
                {
                    for (int i = 0; i < ch.Length; i++)
                    {
                        if (sort[i] == ',' || sort[i] == ' ')
                        {
                            count++;

                            if (count == ch.Length)
                                flag = true;
                        }

                        for (int j = 0; j < alphabet.Length; j++)
                        {      
                            if (sort[i] == alphabet[j])
                            {
                                count++;

                                if (count == ch.Length)
                                    flag = true;

                                break;
                            }
                        }
                    }
                }
            }
                return flag;            
        }

        //Treiner Mode
        private void button1_Click(object sender, EventArgs e)
        { 
            Form3 f3 = new Form3();

            f3.ShowDialog();

            listBox1.SelectedItems.Clear();
            listBox1.Items.Clear();
            GeneralUpdateRadiobuttons();
        }
    }
  
}
