﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace MyDictionary
{
    public partial class FormNewDic : Form
    {
        public FormNewDic()
        {
            InitializeComponent();

            this.button1.Enabled = false;
        }

        //Create New file dictionary
        private void button1_Click(object sender, EventArgs e)
        {              
            //compair new name with simila names files in directory
            if (NameFile.GetNamesForm1(this.textBox1.Text + ".txt"))
            {
                string str = this.textBox1.Text;

                str = DictionaryWindow.SpaceDel(ref str);

                this.textBox1.Text = str;

                if (this.textBox1.Text.Length >= 15)
                    MessageBox.Show("Enter Name not more 15 symbols");
                
                if (this.textBox1 != null && this.textBox1.Text.Length < 15)
                {
                        using (FileStream fs = new FileStream(Form1.path + textBox1.Text + ".txt", FileMode.Create, FileAccess.ReadWrite))
                        {
                            if(Form1.GetNameSTR != null)
                              Form1.GetNameSTR = textBox1.Text + ".txt";

                            fs.Close();

                            this.Close();
                        }
                 }
            }
            else
                MessageBox.Show("This Name exists!\n try other name");
           }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                this.button1.Enabled = true;
            }
        }
    }

    public class NameFile : Form1
    {
        public static bool GetNamesForm1(string str)
        {
            bool flag = true;

            for(int i = 0; i < nameFiles.Length; i++)
                if (str == nameFiles[i])
                {
                    flag = false;
                    break;
                }
            
            return flag;
        }
    }
}
